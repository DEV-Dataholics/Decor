import{a as e,c as t,i as n,r,t as i}from"./createLucideIcon-B0xVD93u.js";import{t as a}from"./package-Dxct0Wnd.js";import{t as o}from"./plus-xmRSFbE-.js";import{t as s}from"./printer-BYi-hTAT.js";import{t as c}from"./save-COvAOUPM.js";import{t as l}from"./search-VVrCa2Q2.js";import{t as u}from"./x-mf97Kuqn.js";import{c as d}from"./index-BZsEq19h.js";var f=i(`image`,[[`rect`,{width:`18`,height:`18`,x:`3`,y:`3`,rx:`2`,ry:`2`,key:`1m3agn`}],[`circle`,{cx:`9`,cy:`9`,r:`2`,key:`af1f0g`}],[`path`,{d:`m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21`,key:`1xmnt7`}]]),p=t(e(),1),m=n();function h(){let{pedidos:e,productos:t,clientes:n,tiendas:i,acabados:h,crearPedido:g,guardarComoProducto:ee}=r(),[_,te]=(0,p.useState)(``),[ne,v]=(0,p.useState)(!1),[y,b]=(0,p.useState)(`cliente_${n[0]?.id||0}`),x=y.startsWith(`tienda_`),S=Number(y.split(`_`)[1]||0),[C,w]=(0,p.useState)([]),[T,E]=(0,p.useState)(``),[re,D]=(0,p.useState)(!1),[O,k]=(0,p.useState)(`linea`),[A,j]=(0,p.useState)(null),[M,N]=(0,p.useState)(``),[P,F]=(0,p.useState)(1),[I,L]=(0,p.useState)(0),[R,z]=(0,p.useState)(0),[B,V]=(0,p.useState)(0),[H,U]=(0,p.useState)(h[0]||``),[W,G]=(0,p.useState)(``),[K,q]=(0,p.useState)(void 0),J=(0,p.useRef)(null),Y=(0,p.useMemo)(()=>e.filter(e=>!_||e.cliente_nombre.toLowerCase().includes(_.toLowerCase())||e.id.toString().includes(_)),[e,_]),X=x?null:n.find(e=>e.id===S),ie=x?i.find(e=>e.id===S):null,ae=(0,p.useMemo)(()=>{let e=t;if(!x&&X){let n=X.nombre.toLowerCase();e=t.filter(e=>Object.keys(e.prices).some(e=>n.includes(e.toLowerCase())||e.toLowerCase().includes(n)))}let n=new Map;return e.forEach(e=>{let t=e.type||`Otros`;n.has(t)||n.set(t,[]),n.get(t).push(e)}),Array.from(n.entries()).sort((e,t)=>e[0].localeCompare(t[0]))},[t,X,x]),Z=A?t.find(e=>e.id===A):null,oe=e=>{let n=t.find(t=>t.id===e);n&&(j(e),n.dimensions&&(L(n.dimensions.width),z(n.dimensions.height),V(n.dimensions.depth)),n.finishes?.length&&U(n.finishes[0]))},se=e=>{let t=e.target.files?.[0];if(!t)return;let n=new FileReader;n.onload=()=>q(n.result),n.readAsDataURL(t)},ce=e=>{if(!e||!X)return 0;let t=Object.keys(e.prices).find(e=>X.nombre.toLowerCase().includes(e.toLowerCase()));return t?e.prices[t]:Object.values(e.prices)[0]||0},le=()=>{let e=O===`orden_especial`?M:Z?.name||``;if(!e)return;let t=Z?ce(Z):0,n={id:Date.now(),producto_id:Z?.id||0,producto_nombre:e,codigo_sku:Z?.sku||`ESP-${Date.now().toString(36).toUpperCase()}`,cantidad:P,precio_unitario:t,subtotal:t*P,tipo_pedido:O,medidas:I||R||B?{ancho:I,alto:R,fondo:B}:void 0,acabado:H,notas:W||void 0,diagrama_url:K};w(e=>[...e,n]),Q()},Q=()=>{D(!1),k(`linea`),j(null),N(``),F(1),L(0),z(0),V(0),U(h[0]||``),G(``),q(void 0)},ue=()=>{if(!C.length||!S)return;let e=C.reduce((e,t)=>e+t.subtotal,0),t=x?ie?.nombre:X?.nombre,n=x?``:X?.email;g({fecha_creacion:new Date().toISOString().split(`T`)[0],estatus:`pendiente`,tipo_orden:C.some(e=>e.tipo_pedido===`orden_especial`)?`especial`:x?`resurtido_tienda`:`mayorista`,cliente_id:S,cliente_nombre:t||``,cliente_email:n||``,total:e,total_items:C.reduce((e,t)=>e+t.cantidad,0),items:C,notas:T}),w([]),E(``),v(!1)},$={linea:`Línea`,linea_especial:`Línea Especial`,orden_especial:`Orden Especial`},de={linea:`bg-blue-500/15 text-blue-400`,linea_especial:`bg-purple-500/15 text-purple-400`,orden_especial:`bg-amber-500/15 text-amber-400`},fe=e=>{let t=e.tipo_orden===`resurtido_tienda`||i.some(t=>t.id===e.cliente_id&&t.nombre===e.cliente_nombre),r=n.find(t=>t.id===e.cliente_id),a=i.find(t=>t.id===e.cliente_id),o=t?a?.ciudad:r?.ciudad,s=t?``:r?.telefono,c=window.open(``,``,`width=800,height=600`);c&&(c.document.write(`
      <html>
        <head>
          <title>Imprimir Orden #${e.id}</title>
          <style>
            @page { margin: 0; size: 80mm auto; }
            body { 
              font-family: 'Courier New', Courier, monospace; 
              font-size: 11px; 
              width: 80mm; 
              padding: 4mm; 
              margin: 0; 
              color: black;
              background: white;
              box-sizing: border-box;
            }
            .header { text-align: center; font-weight: bold; font-size: 18px; margin-bottom: 5px; font-style: italic; }
            .invoice-no { text-align: right; font-weight: bold; margin-bottom: 10px; font-size: 12px; }
            .info { margin-bottom: 10px; line-height: 1.4; display: flex; justify-content: space-between; font-size: 10px; border-bottom: 1px solid black; padding-bottom: 5px; }
            .info-col { flex: 1; }
            table { width: 100%; border-collapse: collapse; margin-bottom: 10px; table-layout: fixed; }
            th, td { text-align: left; padding: 4px 1px; font-size: 10px; vertical-align: top; word-wrap: break-word; }
            th { border-bottom: 1px solid black; border-top: 1px solid black; font-weight: bold; }
            .right { text-align: right; }
            .center { text-align: center; }
            .totals { display: flex; flex-direction: column; align-items: flex-end; width: 100%; }
            .totals-row { display: flex; justify-content: space-between; width: 60%; margin-bottom: 2px; font-size: 10px; }
            .totals-row span:first-child { text-align: right; padding-right: 10px; flex-grow: 1; }
            .totals-row span:last-child { width: 50px; text-align: right; }
            .bold { font-weight: bold; }
            .total-final { border-top: 1px solid black; border-bottom: 1px solid black; padding: 3px 0; font-size: 11px; margin-top: 2px; }
          </style>
        </head>
        <body>
          <div class="header">SILVA WOOD FACTORY</div>
          <div class="invoice-no">Invoice No &nbsp;&nbsp;&nbsp; #${e.id}</div>
          
          <div style="display: flex; gap: 5px; font-size: 10px; margin-bottom: 5px;">
            <div style="width: 60%;">
              <div><strong style="display:inline-block; width:50px;">Customer</strong> ${e.cliente_nombre}</div>
              <div><strong style="display:inline-block; width:50px;">Address</strong> -</div>
              <div><strong style="display:inline-block; width:50px;">City</strong> ${o||`-`}</div>
            </div>
            <div style="width: 40%; border-left: 1px solid black; padding-left: 5px;">
              <div><strong>Date</strong> ${e.fecha_creacion}</div>
              <div><strong>Phone</strong> ${s||`-`}</div>
              <div><strong>Fax</strong> -</div>
            </div>
          </div>
          <div style="font-size: 10px; margin-bottom: 10px; border-bottom: 1px solid black; padding-bottom: 5px;">
             <strong style="display:inline-block; width:50px;">State</strong> - &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>Zip</strong> -
          </div>
          
          <table>
            <thead>
              <tr>
                <th style="width: 20%">CODE</th>
                <th class="center" style="width: 12%">Qty</th>
                <th style="width: 48%">Description</th>
                <th class="right" style="width: 20%">TOTAL</th>
              </tr>
            </thead>
            <tbody>
              ${e.items.map(e=>`
                <tr>
                  <td>${e.codigo_sku||`-`}</td>
                  <td class="center">${e.cantidad}</td>
                  <td>${e.producto_nombre}${e.acabado?`<br/><small>${e.acabado}</small>`:``}</td>
                  <td class="right">${(e.precio_unitario*e.cantidad).toFixed(2)}</td>
                </tr>
              `).join(``)}
            </tbody>
          </table>
          
          <div class="totals">
            <div class="totals-row">
              <span>Subtotal</span>
              <span>${e.total.toFixed(2)}</span>
            </div>
            <div class="totals-row">
              <span>Freight</span>
              <span>0.00</span>
            </div>
            <div class="totals-row bold total-final">
              <span>TOTAL</span>
              <span>${e.total.toFixed(2)}</span>
            </div>
          </div>
          
          <script>
            window.onload = () => { setTimeout(() => { window.print(); window.close(); }, 300); };
          <\/script>
        </body>
      </html>
    `),c.document.close())};return(0,m.jsxs)(`div`,{className:`space-y-5`,children:[(0,m.jsxs)(`div`,{className:`flex flex-col sm:flex-row gap-3`,children:[(0,m.jsxs)(`div`,{className:`relative flex-1`,children:[(0,m.jsx)(l,{className:`absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500`,size:16}),(0,m.jsx)(`input`,{type:`text`,placeholder:`Buscar pedido...`,value:_,onChange:e=>te(e.target.value),className:`input-dark pl-10`})]}),(0,m.jsxs)(`button`,{onClick:()=>v(!0),className:`btn-primary shrink-0`,children:[(0,m.jsx)(o,{size:16}),` Nueva Orden`]})]}),(0,m.jsxs)(`div`,{className:`grid grid-cols-1 lg:grid-cols-2 gap-3`,children:[Y.map(e=>(0,m.jsxs)(`div`,{className:`glass-card p-5 space-y-3 hover:border-amber-500/20 transition-all`,children:[(0,m.jsxs)(`div`,{className:`flex justify-between items-start`,children:[(0,m.jsxs)(`div`,{children:[(0,m.jsxs)(`h3`,{className:`text-sm font-bold text-zinc-100 flex items-center gap-2`,children:[(0,m.jsx)(d,{size:16,className:`text-amber-400`}),` Orden #`,e.id]}),(0,m.jsxs)(`p`,{className:`text-[10px] text-zinc-500`,children:[e.cliente_nombre,` · `,e.fecha_creacion]})]}),(0,m.jsx)(`span`,{className:`px-2 py-0.5 rounded-full text-[10px] font-bold ${e.tipo_orden===`especial`?`bg-amber-500/15 text-amber-400`:`bg-blue-500/15 text-blue-400`}`,children:e.tipo_orden===`especial`?`Especial`:`Línea`})]}),(0,m.jsx)(`div`,{className:`space-y-1.5`,children:e.items.map(e=>(0,m.jsxs)(`div`,{className:`bg-zinc-800/40 rounded-lg p-2.5 flex items-center gap-3`,children:[e.diagrama_url&&(0,m.jsx)(`img`,{src:e.diagrama_url,alt:``,className:`w-10 h-10 rounded object-cover shrink-0`}),(0,m.jsxs)(`div`,{className:`flex-1 min-w-0`,children:[(0,m.jsx)(`p`,{className:`text-xs font-semibold text-zinc-200 truncate`,children:e.producto_nombre}),(0,m.jsxs)(`p`,{className:`text-[10px] text-zinc-500`,children:[e.tipo_pedido&&(0,m.jsx)(`span`,{className:`${de[e.tipo_pedido]} px-1 py-0 rounded text-[8px] font-bold mr-1`,children:$[e.tipo_pedido]}),e.acabado&&(0,m.jsx)(`span`,{className:`text-amber-400`,children:e.acabado}),e.medidas&&(0,m.jsxs)(`span`,{className:`ml-1`,children:[`· `,e.medidas.ancho,`×`,e.medidas.alto,`×`,e.medidas.fondo,`″`]})]})]}),(0,m.jsxs)(`p`,{className:`text-xs font-bold text-zinc-300 shrink-0`,children:[`×`,e.cantidad]})]},e.id))}),(0,m.jsx)(`div`,{className:`flex justify-between items-center pt-1 border-t border-zinc-800/30`,children:(0,m.jsxs)(`div`,{className:`flex justify-between items-center text-zinc-500 text-xs w-full`,children:[(0,m.jsxs)(`p`,{children:[e.total_items,` piezas`]}),(0,m.jsxs)(`p`,{className:`font-bold text-amber-400 text-sm`,children:[`$`,e.total.toLocaleString(`es-MX`,{minimumFractionDigits:2})]})]})}),(0,m.jsxs)(`div`,{className:`flex gap-2`,children:[(0,m.jsxs)(`button`,{onClick:()=>fe(e),className:`btn-secondary text-xs flex-1 justify-center`,children:[(0,m.jsx)(s,{size:14}),` Imprimir Orden`]}),e.items.some(e=>e.tipo_pedido===`orden_especial`&&!e.producto_id)&&(0,m.jsxs)(`button`,{onClick:()=>{let t=e.items.find(e=>e.tipo_pedido===`orden_especial`&&!e.producto_id);t&&ee(t)},className:`btn-secondary text-xs flex-1 justify-center`,children:[(0,m.jsx)(a,{size:14}),` Guardar Especial como Producto`]})]})]},e.id)),Y.length===0&&(0,m.jsx)(`p`,{className:`col-span-2 text-center text-sm text-zinc-600 py-8`,children:`Sin pedidos registrados`})]}),ne&&(0,m.jsx)(`div`,{className:`fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in`,children:(0,m.jsxs)(`div`,{className:`glass-card w-full max-w-2xl max-h-[90vh] overflow-y-auto animate-scale-in`,children:[(0,m.jsxs)(`div`,{className:`px-6 py-4 border-b border-zinc-700/50 flex justify-between items-center sticky top-0 bg-zinc-800/90 backdrop-blur-sm z-10`,children:[(0,m.jsxs)(`h3`,{className:`font-bold text-zinc-100 flex items-center gap-2`,children:[(0,m.jsx)(d,{size:18,className:`text-amber-400`}),` Nueva Orden`]}),(0,m.jsx)(`button`,{onClick:()=>v(!1),className:`text-zinc-500 hover:text-zinc-300`,children:(0,m.jsx)(u,{size:18})})]}),(0,m.jsxs)(`div`,{className:`p-6 space-y-4`,children:[(0,m.jsxs)(`div`,{children:[(0,m.jsx)(`label`,{className:`text-[10px] font-semibold text-zinc-500 uppercase mb-1 block`,children:`Destino (Cliente o Sucursal)`}),(0,m.jsxs)(`select`,{value:y,onChange:e=>b(e.target.value),className:`input-dark`,children:[(0,m.jsx)(`optgroup`,{label:`Clientes Mayoristas`,children:n.map(e=>(0,m.jsxs)(`option`,{value:`cliente_${e.id}`,className:`bg-zinc-900`,children:[e.nombre,` (`,e.ciudad,`)`]},`cliente_${e.id}`))}),(0,m.jsx)(`optgroup`,{label:`Sucursales Propias`,children:i.map(e=>(0,m.jsx)(`option`,{value:`tienda_${e.id}`,className:`bg-zinc-900`,children:e.nombre},`tienda_${e.id}`))})]})]}),C.length>0&&(0,m.jsxs)(`div`,{className:`space-y-2`,children:[(0,m.jsxs)(`h4`,{className:`text-xs font-bold text-zinc-400`,children:[`Artículos (`,C.length,`)`]}),C.map((e,t)=>(0,m.jsxs)(`div`,{className:`bg-zinc-800/40 rounded-lg p-3 flex items-center gap-3`,children:[e.diagrama_url&&(0,m.jsx)(`img`,{src:e.diagrama_url,alt:``,className:`w-10 h-10 rounded object-cover shrink-0`}),(0,m.jsxs)(`div`,{className:`flex-1 min-w-0`,children:[(0,m.jsx)(`p`,{className:`text-xs font-semibold text-zinc-200 truncate`,children:e.producto_nombre}),(0,m.jsxs)(`p`,{className:`text-[10px] text-zinc-500`,children:[$[e.tipo_pedido],` · `,e.acabado,` · `,e.medidas?`${e.medidas.ancho}×${e.medidas.alto}×${e.medidas.fondo}″`:`Sin medidas`]})]}),(0,m.jsxs)(`p`,{className:`text-xs font-bold text-zinc-300 shrink-0`,children:[`×`,e.cantidad]}),(0,m.jsx)(`button`,{onClick:()=>w(e=>e.filter((e,n)=>n!==t)),className:`text-zinc-600 hover:text-red-400`,children:(0,m.jsx)(u,{size:14})})]},e.id))]}),re?(0,m.jsxs)(`div`,{className:`glass-card p-4 space-y-3 border-amber-500/20`,children:[(0,m.jsx)(`h4`,{className:`text-xs font-bold text-amber-400`,children:`Nuevo Artículo`}),(0,m.jsx)(`div`,{className:`flex gap-1`,children:[`linea`,`linea_especial`,`orden_especial`].map(e=>(0,m.jsx)(`button`,{onClick:()=>{k(e),j(null)},className:`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${O===e?`bg-amber-500/20 text-amber-400`:`text-zinc-500 hover:text-zinc-300 bg-zinc-800/40`}`,children:$[e]},e))}),O===`orden_especial`?(0,m.jsx)(`input`,{value:M,onChange:e=>N(e.target.value),className:`input-dark`,placeholder:`Nombre del mueble especial`}):(0,m.jsx)(`div`,{className:`relative`,children:(0,m.jsxs)(`select`,{value:A||``,onChange:e=>oe(Number(e.target.value)),className:`input-dark w-full`,children:[(0,m.jsx)(`option`,{value:``,disabled:!0,children:`Seleccione un producto...`}),ae.map(([e,t])=>(0,m.jsx)(`optgroup`,{label:e,className:`bg-zinc-900 font-bold text-amber-500`,children:t.map(e=>(0,m.jsx)(`option`,{value:e.id,className:`text-zinc-200 font-normal`,children:e.name},e.id))},e))]})}),(0,m.jsxs)(`div`,{className:`grid grid-cols-3 gap-2`,children:[(0,m.jsxs)(`div`,{children:[(0,m.jsx)(`label`,{className:`text-[9px] text-zinc-500 block mb-0.5`,children:`Ancho (″)`}),(0,m.jsx)(`input`,{type:`number`,value:I||``,onChange:e=>L(Number(e.target.value)),className:`input-dark`})]}),(0,m.jsxs)(`div`,{children:[(0,m.jsx)(`label`,{className:`text-[9px] text-zinc-500 block mb-0.5`,children:`Alto (″)`}),(0,m.jsx)(`input`,{type:`number`,value:R||``,onChange:e=>z(Number(e.target.value)),className:`input-dark`})]}),(0,m.jsxs)(`div`,{children:[(0,m.jsx)(`label`,{className:`text-[9px] text-zinc-500 block mb-0.5`,children:`Fondo (″)`}),(0,m.jsx)(`input`,{type:`number`,value:B||``,onChange:e=>V(Number(e.target.value)),className:`input-dark`})]})]}),(0,m.jsxs)(`div`,{className:`grid grid-cols-2 gap-2`,children:[(0,m.jsxs)(`div`,{children:[(0,m.jsx)(`label`,{className:`text-[9px] text-zinc-500 block mb-0.5`,children:`Acabado`}),(0,m.jsx)(`select`,{value:H,onChange:e=>U(e.target.value),className:`input-dark`,children:h.map(e=>(0,m.jsx)(`option`,{value:e,className:`bg-zinc-900`,children:e},e))})]}),(0,m.jsxs)(`div`,{children:[(0,m.jsx)(`label`,{className:`text-[9px] text-zinc-500 block mb-0.5`,children:`Cantidad`}),(0,m.jsx)(`input`,{type:`number`,min:1,value:P,onChange:e=>F(Math.max(1,Number(e.target.value))),className:`input-dark`})]})]}),(0,m.jsx)(`textarea`,{value:W,onChange:e=>G(e.target.value),className:`input-dark`,rows:2,placeholder:`Notas/especificaciones...`}),(0,m.jsxs)(`div`,{children:[(0,m.jsx)(`input`,{type:`file`,accept:`image/*`,ref:J,onChange:se,className:`hidden`}),(0,m.jsxs)(`button`,{onClick:()=>J.current?.click(),className:`btn-ghost text-xs w-full justify-center`,children:[(0,m.jsx)(f,{size:14}),` `,K?`Cambiar Foto/Diagrama`:`Adjuntar Foto/Diagrama`]}),K&&(0,m.jsx)(`img`,{src:K,alt:`preview`,className:`mt-2 w-full h-32 object-contain rounded-lg border border-zinc-700/30`})]}),(0,m.jsxs)(`div`,{className:`flex gap-2`,children:[(0,m.jsx)(`button`,{onClick:Q,className:`btn-ghost flex-1 justify-center text-xs`,children:`Cancelar`}),(0,m.jsxs)(`button`,{onClick:le,className:`btn-primary flex-1 justify-center text-xs`,children:[(0,m.jsx)(o,{size:14}),` Agregar`]})]})]}):(0,m.jsxs)(`button`,{onClick:()=>D(!0),className:`btn-secondary w-full justify-center`,children:[(0,m.jsx)(o,{size:14}),` Agregar Artículo`]}),(0,m.jsx)(`textarea`,{value:T,onChange:e=>E(e.target.value),className:`input-dark`,rows:2,placeholder:`Notas generales de la orden...`}),(0,m.jsxs)(`div`,{className:`flex gap-3 pt-2`,children:[(0,m.jsx)(`button`,{onClick:()=>v(!1),className:`btn-ghost flex-1 justify-center`,children:`Cancelar`}),(0,m.jsxs)(`button`,{onClick:ue,disabled:!C.length,className:`btn-primary flex-1 justify-center disabled:opacity-40`,children:[(0,m.jsx)(c,{size:14}),` Crear Orden (`,C.length,` artículos)`]})]})]})]})})]})}export{h as default};