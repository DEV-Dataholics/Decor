import{a as e,c as t,i as n,r,t as i}from"./createLucideIcon-DgZNS6dp.js";import{t as a}from"./package-CGTp_uMh.js";import{t as o}from"./plus-DVAQCSZf.js";import{t as s}from"./printer-ButYHq3D.js";import{t as c}from"./search-DPTOtsE_.js";import{t as l}from"./store-CGuc8Bk3.js";import{t as u}from"./timer-DKWCSkms.js";import{t as d}from"./triangle-alert-DPkHZrgy.js";import{t as f}from"./x-DMN1lWi1.js";import{n as p,t as m}from"./QRLabel-C7lRXWRR.js";var h=i(`minus`,[[`path`,{d:`M5 12h14`,key:`1ays0h`}]]),g=i(`qr-code`,[[`rect`,{width:`5`,height:`5`,x:`3`,y:`3`,rx:`1`,key:`1tu5fj`}],[`rect`,{width:`5`,height:`5`,x:`16`,y:`3`,rx:`1`,key:`1v8r4q`}],[`rect`,{width:`5`,height:`5`,x:`3`,y:`16`,rx:`1`,key:`1x03jg`}],[`path`,{d:`M21 16h-3a2 2 0 0 0-2 2v3`,key:`177gqh`}],[`path`,{d:`M21 21v.01`,key:`ents32`}],[`path`,{d:`M12 7v3a2 2 0 0 1-2 2H7`,key:`8crl2c`}],[`path`,{d:`M3 12h.01`,key:`nlz23k`}],[`path`,{d:`M12 3h.01`,key:`n36tog`}],[`path`,{d:`M12 16v.01`,key:`133mhm`}],[`path`,{d:`M16 12h1`,key:`1slzba`}],[`path`,{d:`M21 12v.01`,key:`1lwtk9`}],[`path`,{d:`M12 21v-1`,key:`1880an`}]]),_=i(`tree-pine`,[[`path`,{d:`m17 14 3 3.3a1 1 0 0 1-.7 1.7H4.7a1 1 0 0 1-.7-1.7L7 14h-.3a1 1 0 0 1-.7-1.7L9 9h-.2A1 1 0 0 1 8 7.3L12 3l4 4.3a1 1 0 0 1-.8 1.7H15l3 3.3a1 1 0 0 1-.7 1.7H17Z`,key:`cpyugq`}],[`path`,{d:`M12 22v-3`,key:`kmzjlo`}]]),v=t(e(),1),y=n();function b(){let{currentUser:e,inventario:t,materiaPrima:n,terminados:i,updateMateriaPrima:b,tiendas:x,productos:S,embarques:C,ventas:w}=r(),T=e?.rol===`gerente_tienda`,E=localStorage.getItem(`decor_pos_tienda_id`)?Number(localStorage.getItem(`decor_pos_tienda_id`)):null,[D,O]=(0,v.useState)(T?`tienda`:`terminados`),[k,A]=(0,v.useState)(``),[j,M]=(0,v.useState)(T?E:null),[N,P]=(0,v.useState)(null),[F,I]=(0,v.useState)(null),L=(0,v.useRef)(null),[R,z]=(0,v.useState)(null),B=(e,t,n,r,i)=>{e.stopPropagation();let a=x.find(e=>e.id===t)?.nombre||`STOCK TIENDA`,o=new Set;C.forEach(e=>{e.estatus===`entregado`&&e.items.forEach(e=>{e.producto_id===n&&e.estado_recepcion===`ok`&&e.tienda_destino_id===t&&o.add(e.qr_code)})}),w.forEach(e=>{e.tienda_id===t&&e.items.forEach(e=>{e.producto_id===n&&o.delete(e.qr_code)})});let s=Array.from(o).slice(0,r),c=0;for(;s.length<r;)s.push(`DCR-REC-${t}-${n}-${Date.now()}-${c}`),c++;I({nombre:i,qrs:s,tiendaNombre:a})},V=(e,t)=>{z({ordenTitle:e,itemsList:t}),setTimeout(()=>{let t=window.open(``,`_blank`);if(!t){z(null);return}let n=L.current?.innerHTML||``;t.document.write(`
        <html>
          <head>
            <title>Imprimir Etiquetas ${e}</title>
            <style>
        @import url('https://fonts.googleapis.com/css2?family=Courier+Prime:wght@400;700&display=swap');
        
        @page {
          size: letter;
          margin: 0;
        }
        
        body {
          margin: 0;
          padding: 0;
          background: white;
          color: black;
          font-family: Arial, Helvetica, sans-serif;
        }

        /* Contenedor de cada página física Avery 5163 (8.5in x 11in) */
        .avery-page {
          width: 8.5in;
          height: 11in;
          box-sizing: border-box;
          padding-top: 0.5in;
          padding-bottom: 0.5in;
          padding-left: 0.16in;
          padding-right: 0.16in;
          page-break-after: always;
          break-after: page;
          display: grid;
          grid-template-columns: 4in 4in;
          grid-template-rows: 2in 2in 2in 2in 2in;
          column-gap: 0.18in;
          row-gap: 0in;
          overflow: hidden;
        }

        /* Cada etiqueta individual (4in x 2in) */
        .avery-label {
          width: 4in;
          height: 2in;
          box-sizing: border-box;
          padding: 0.15in 0.25in;
          display: flex;
          align-items: center;
          gap: 0.2in;
          border: 1px dashed #ccc;
          overflow: hidden;
          background: white;
        }

        .qr-container {
          width: 1.1in;
          height: 1.1in;
          display: flex;
          align-items: center;
          justify-content: center;
          background: white;
          box-sizing: border-box;
          flex-shrink: 0;
        }

        .qr-container svg {
          width: 100%;
          height: 100%;
        }

        .info-container {
          flex: 1;
          display: flex;
          flex-direction: column;
          justify-content: center;
          min-width: 0;
          line-height: 1.3;
        }

        .info-title {
          font-size: 11px;
          font-weight: 900;
          margin: 0 0 3px 0;
          text-transform: uppercase;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        .info-subtitle {
          font-size: 9px;
          color: #000;
          margin: 0 0 2px 0;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        .info-qr-text {
          font-size: 9px;
          font-weight: bold;
          font-family: Arial, Helvetica, sans-serif;
          color: #000;
          word-break: break-all;
          margin: 4px 0 0 0;
          line-height: 1.2;
        }
      </style>
          </head>
          <body>
            ${n}
            <script>
              window.onload = function() {
                setTimeout(function() {
                  window.print();
                  window.close();
                }, 250);
              };
            <\/script>
          </body>
        </html>
      `),t.document.close(),z(null)},150)},H=(0,v.useMemo)(()=>[...n].sort((e,t)=>e.cantidad/e.minimo-t.cantidad/t.minimo),[n]),U=(0,v.useMemo)(()=>{if(!j)return x.map(e=>{let n=t.filter(t=>t.tienda_id===e.id).reduce((e,t)=>e+t.cantidad_disponible,0);return{type:`tienda`,id:e.id,name:e.nombre,count:n}});let e=t.filter(e=>e.tienda_id===j);if(!N){let t=new Map;return e.forEach(e=>{let n=S.find(t=>t.id===e.producto_id)?.type||`Otros`;t.set(n,(t.get(n)||0)+e.cantidad_disponible)}),Array.from(t.entries()).map(([e,t])=>({type:`category`,id:e,name:e,count:t}))}let n=new Map;return e.forEach(e=>{let t=S.find(t=>t.id===e.producto_id);(t?.type||`Otros`)===N&&(n.has(e.producto_id)||n.set(e.producto_id,{producto:t||{id:e.producto_id,name:e.producto_nombre||`Mueble`,type:`Otros`,prices:{1:e.precio_venta},sku:``,dimensions:``,finishes:[],image_url:``},total:0,price:e.precio_venta}),n.get(e.producto_id).total+=e.cantidad_disponible)}),Array.from(n.values()).filter(e=>e.total>0).sort((e,t)=>t.total-e.total).map(e=>({type:`product`,id:e.producto.id,name:e.producto.name,count:e.total,price:e.price}))},[t,S,x,j,N]),W=(0,v.useMemo)(()=>{let e=Date.now(),t=i.map(t=>({...t,dias:Math.floor((e-new Date(t.fecha_listo).getTime())/864e5)})).filter(e=>!k||e.producto_nombre.toLowerCase().includes(k.toLowerCase())||e.cliente_nombre.toLowerCase().includes(k.toLowerCase())||e.qr_code.toLowerCase().includes(k.toLowerCase())),n=new Map;return t.forEach(e=>{let t=`Orden #${e.orden_id}`;n.has(t)||n.set(t,[]),n.get(t).push(e)}),Array.from(n.entries()).sort((e,t)=>t[1].length-e[1].length)},[i,k]),G=[{key:`terminados`,label:`Terminados sin Embarcar`,icon:(0,y.jsx)(a,{size:14}),count:i.length},{key:`tienda`,label:`Tienda`,icon:(0,y.jsx)(l,{size:14}),count:t.reduce((e,t)=>e+t.cantidad_disponible,0)},{key:`materia_prima`,label:`Materia Prima`,icon:(0,y.jsx)(_,{size:14}),count:n.length}].filter(e=>T?e.key===`tienda`:!0);return(0,y.jsxs)(`div`,{className:`space-y-5`,children:[!T&&(0,y.jsx)(`div`,{className:`flex gap-1.5 overflow-x-auto scrollbar-hide`,children:G.map(e=>(0,y.jsxs)(`button`,{onClick:()=>{O(e.key),A(``)},className:`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${D===e.key?`bg-amber-500/15 text-amber-400`:`text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800/40`}`,children:[e.icon,` `,e.label,` `,(0,y.jsxs)(`span`,{className:`text-[10px] opacity-60`,children:[`(`,e.count,`)`]})]},e.key))}),D===`materia_prima`&&(0,y.jsx)(`div`,{className:`grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3`,children:H.map(e=>{let t=Math.min(100,e.cantidad/(e.minimo*3)*100),n=e.cantidad<=e.minimo;return(0,y.jsxs)(`div`,{className:`glass-card p-5 space-y-3 ${n?`border-red-500/30 bg-red-500/5`:``}`,children:[(0,y.jsxs)(`div`,{className:`flex items-center justify-between`,children:[(0,y.jsxs)(`div`,{className:`flex items-center gap-2`,children:[(0,y.jsx)(`span`,{className:`w-4 h-4 rounded-full`,style:{background:e.color}}),(0,y.jsx)(`h3`,{className:`text-sm font-bold text-zinc-100`,children:e.nombre})]}),n&&(0,y.jsx)(d,{size:16,className:`text-red-400 animate-pulse`})]}),(0,y.jsxs)(`div`,{className:`text-center`,children:[(0,y.jsx)(`p`,{className:`text-3xl font-black ${n?`text-red-400`:`text-zinc-100`}`,children:e.cantidad}),(0,y.jsx)(`p`,{className:`text-xs text-zinc-500`,children:e.unidad})]}),(0,y.jsxs)(`div`,{className:`relative h-2 bg-zinc-800 rounded-full overflow-hidden`,children:[(0,y.jsx)(`div`,{className:`absolute left-0 top-0 h-full rounded-full transition-all duration-500 ${n?`bg-red-500`:t>50?`bg-emerald-500`:`bg-amber-500`}`,style:{width:`${t}%`}}),(0,y.jsx)(`div`,{className:`absolute top-0 h-full w-0.5 bg-zinc-500`,style:{left:`${e.minimo/(e.minimo*3)*100}%`}})]}),(0,y.jsxs)(`p`,{className:`text-[10px] text-zinc-600 text-center`,children:[`Mínimo: `,e.minimo,` `,e.unidad]}),(0,y.jsxs)(`div`,{className:`flex gap-2 justify-center`,children:[(0,y.jsx)(`button`,{onClick:()=>b(e.id,-1),className:`w-8 h-8 flex items-center justify-center rounded-lg bg-zinc-800 text-zinc-400 hover:bg-zinc-700 hover:text-zinc-200 transition-all`,children:(0,y.jsx)(h,{size:14})}),(0,y.jsx)(`button`,{onClick:()=>b(e.id,1),className:`w-8 h-8 flex items-center justify-center rounded-lg bg-amber-500/15 text-amber-400 hover:bg-amber-500/25 transition-all`,children:(0,y.jsx)(o,{size:14})}),(0,y.jsx)(`button`,{onClick:()=>b(e.id,5),className:`h-8 px-3 flex items-center justify-center rounded-lg bg-emerald-500/15 text-emerald-400 hover:bg-emerald-500/25 transition-all text-xs font-bold`,children:`+5`})]})]},e.id)})}),D===`terminados`&&(0,y.jsxs)(`div`,{className:`space-y-4`,children:[(0,y.jsxs)(`div`,{className:`relative`,children:[(0,y.jsx)(c,{className:`absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500`,size:16}),(0,y.jsx)(`input`,{type:`text`,placeholder:`Buscar por producto, cliente o QR...`,value:k,onChange:e=>A(e.target.value),className:`input-dark pl-10`})]}),(0,y.jsx)(`div`,{className:`grid grid-cols-1 lg:grid-cols-2 gap-4`,children:W.length===0?(0,y.jsx)(`div`,{className:`col-span-full glass-card p-12 text-center`,children:(0,y.jsx)(`p`,{className:`text-zinc-600 text-sm`,children:`Sin piezas terminadas encontradas`})}):W.map(([e,t])=>(0,y.jsxs)(`div`,{className:`glass-card p-4 space-y-3`,children:[(0,y.jsxs)(`div`,{className:`flex justify-between items-center border-b border-zinc-700/50 pb-2`,children:[(0,y.jsxs)(`div`,{className:`flex items-center gap-3`,children:[(0,y.jsx)(`h3`,{className:`text-sm font-bold text-zinc-100`,children:e}),(0,y.jsxs)(`button`,{onClick:()=>V(e,t),className:`p-1 px-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-amber-400 rounded-lg border border-zinc-700/50 transition-colors flex items-center gap-1.5 text-[10px] font-bold`,title:`Imprimir todas las etiquetas de esta orden en formato Avery`,children:[(0,y.jsx)(s,{size:12}),` Imprimir Orden Completa`]})]}),(0,y.jsxs)(`span`,{className:`bg-amber-500/15 text-amber-400 px-2 py-0.5 rounded-full text-xs font-bold`,children:[t.length,` piezas`]})]}),(0,y.jsx)(`div`,{className:`space-y-2 max-h-64 overflow-y-auto pr-2 scrollbar-hide`,children:t.map(e=>(0,y.jsxs)(`div`,{className:`bg-zinc-800/40 p-3 rounded-lg flex items-center gap-3 border transition-colors ${e.dias>7?`border-red-500/30`:`border-zinc-700/30`}`,children:[(0,y.jsx)(`div`,{className:`shrink-0`,children:(0,y.jsx)(m,{qrCode:e.qr_code,productoNombre:e.producto_nombre,ordenId:e.orden_id,clienteNombre:e.cliente_nombre,acabado:e.acabado,size:40,showPrint:!0})}),(0,y.jsxs)(`div`,{className:`flex-1 min-w-0`,children:[(0,y.jsxs)(`p`,{className:`text-xs text-zinc-300`,children:[e.cliente_nombre,` · `,e.acabado]}),(0,y.jsx)(`p`,{className:`text-[10px] font-mono text-zinc-500`,children:e.qr_code})]}),(0,y.jsx)(`div`,{className:`text-right shrink-0`,children:(0,y.jsxs)(`div`,{className:`flex items-center gap-1 ${e.dias>7?`text-red-400`:e.dias>3?`text-amber-400`:`text-emerald-400`}`,children:[(0,y.jsx)(u,{size:12}),(0,y.jsxs)(`span`,{className:`text-[10px] font-bold`,children:[e.dias,` días`]})]})})]},e.id))})]},e))})]}),D===`tienda`&&(0,y.jsxs)(`div`,{className:`space-y-4`,children:[(0,y.jsxs)(`div`,{className:`flex items-center gap-2 text-xs font-semibold text-zinc-400 bg-zinc-800/30 px-4 py-2.5 rounded-lg border border-zinc-700/30`,children:[T?(0,y.jsx)(`span`,{className:`text-zinc-300`,children:E?x.find(e=>e.id===E)?.nombre:`Seleccionar Tienda`}):(0,y.jsx)(`button`,{onClick:()=>{M(null),P(null)},className:`hover:text-amber-400 ${j?``:`text-amber-400`}`,children:`Todas las Tiendas`}),T&&!E&&j&&(0,y.jsxs)(y.Fragment,{children:[(0,y.jsx)(`span`,{className:`text-zinc-600`,children:`/`}),(0,y.jsx)(`button`,{onClick:()=>P(null),className:`hover:text-amber-400 ${N?``:`text-amber-400`}`,children:x.find(e=>e.id===j)?.nombre})]}),!T&&j&&(0,y.jsxs)(y.Fragment,{children:[(0,y.jsx)(`span`,{className:`text-zinc-600`,children:`/`}),(0,y.jsx)(`button`,{onClick:()=>P(null),className:`hover:text-amber-400 ${N?``:`text-amber-400`}`,children:x.find(e=>e.id===j)?.nombre})]}),N&&(0,y.jsxs)(y.Fragment,{children:[(0,y.jsx)(`span`,{className:`text-zinc-600`,children:`/`}),(0,y.jsx)(`span`,{className:`text-amber-400`,children:N})]})]}),(0,y.jsx)(`div`,{className:`grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3`,children:U.length===0?(0,y.jsx)(`div`,{className:`col-span-full glass-card p-12 text-center`,children:(0,y.jsx)(`p`,{className:`text-zinc-600 text-sm`,children:`No hay inventario en esta sección`})}):U.map(e=>(0,y.jsxs)(`div`,{onClick:()=>{e.type===`tienda`?M(e.id):e.type===`category`&&P(e.id)},className:`glass-card p-4 flex flex-col items-center text-center transition-colors relative ${e.type===`product`?``:`hover:border-amber-500/50 hover:bg-zinc-800/40 cursor-pointer`}`,children:[(0,y.jsx)(`div`,{className:`w-16 h-16 rounded-xl bg-zinc-800 flex items-center justify-center mb-3 ${e.type===`product`?`text-zinc-500`:`text-amber-400 group-hover:scale-110 transition-transform`}`,children:e.type===`tienda`?(0,y.jsx)(l,{size:32}):e.type===`category`?(0,y.jsx)(a,{size:32}):(0,y.jsx)(l,{size:32})}),(0,y.jsx)(`h3`,{className:`text-xs font-bold text-zinc-200 line-clamp-2 min-h-[32px]`,children:e.name}),(0,y.jsx)(`div`,{className:`mt-2 text-2xl font-black text-amber-400`,children:e.count}),(0,y.jsx)(`p`,{className:`text-[10px] text-zinc-500 uppercase font-semibold`,children:e.type===`tienda`?`Piezas Totales`:e.type===`category`?`Piezas`:`En Stock`}),e.type===`product`&&e.price&&(0,y.jsxs)(`p`,{className:`mt-2 text-[10px] text-zinc-400 bg-zinc-800/50 px-2 py-1 rounded w-full`,children:[`$`,e.price.toLocaleString(`es-MX`,{minimumFractionDigits:2})]}),e.type===`product`&&(0,y.jsx)(`button`,{onClick:t=>B(t,j,e.id,e.count,e.name),className:`absolute top-2 right-2 p-1.5 text-zinc-500 hover:text-amber-400 hover:bg-zinc-800 rounded transition-colors`,title:`Imprimir QRs`,children:(0,y.jsx)(g,{size:14})})]},e.id))})]}),F&&(0,y.jsx)(`div`,{className:`fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 print:hidden`,children:(0,y.jsxs)(`div`,{className:`glass-card w-full max-w-2xl max-h-[85vh] flex flex-col`,children:[(0,y.jsxs)(`div`,{className:`p-4 border-b border-zinc-700/50 flex justify-between items-center bg-zinc-800/90 rounded-t-2xl`,children:[(0,y.jsxs)(`h3`,{className:`font-bold text-zinc-100 flex items-center gap-2`,children:[(0,y.jsx)(s,{size:18,className:`text-amber-400`}),` Imprimir Etiquetas: `,F.nombre]}),(0,y.jsx)(`button`,{onClick:()=>I(null),className:`text-zinc-500 hover:text-zinc-300`,children:(0,y.jsx)(f,{size:18})})]}),(0,y.jsx)(`div`,{className:`p-6 overflow-y-auto space-y-4 print-only-container flex-1`,children:(0,y.jsx)(`div`,{className:`grid grid-cols-2 gap-4`,children:F.qrs.map(e=>(0,y.jsx)(m,{qrCode:e,productoNombre:F.nombre,ordenId:0,clienteNombre:F.tiendaNombre,acabado:`-`,size:120},e))})}),(0,y.jsxs)(`div`,{className:`p-4 border-t border-zinc-700/50 flex justify-end gap-3 bg-zinc-800/90 rounded-b-2xl`,children:[(0,y.jsx)(`button`,{onClick:()=>I(null),className:`btn-ghost`,children:`Cancelar`}),(0,y.jsxs)(`button`,{onClick:()=>window.print(),className:`btn-primary`,children:[(0,y.jsx)(s,{size:16}),` Imprimir `,F.qrs.length,` Etiquetas`]})]})]})}),(0,y.jsx)(`div`,{style:{display:`none`},ref:L,children:R&&(()=>{let e=[];for(let t=0;t<R.itemsList.length;t+=10)e.push(R.itemsList.slice(t,t+10));return e.map((e,t)=>(0,y.jsx)(`div`,{className:`avery-page`,children:e.map(e=>(0,y.jsxs)(`div`,{className:`avery-label`,children:[(0,y.jsx)(`div`,{className:`qr-container`,children:(0,y.jsx)(p,{value:e.qr_code,size:80,level:`M`})}),(0,y.jsxs)(`div`,{className:`info-container`,children:[(0,y.jsx)(`h1`,{className:`info-title`,children:e.producto_nombre}),(0,y.jsxs)(`p`,{className:`info-subtitle`,children:[(0,y.jsx)(`strong`,{children:`Ord:`}),` #`,e.orden_id]}),(0,y.jsxs)(`p`,{className:`info-subtitle`,children:[(0,y.jsx)(`strong`,{children:`Destino:`}),` `,e.cliente_nombre]}),(0,y.jsxs)(`p`,{className:`info-subtitle`,children:[(0,y.jsx)(`strong`,{children:`Acabado:`}),` `,e.acabado]}),(0,y.jsx)(`p`,{className:`info-qr-text`,children:e.qr_code})]})]},e.id))},t))})()}),(0,y.jsxs)(`div`,{className:`hidden print:block print:w-full print:absolute print:top-0 print:left-0 print:bg-white print:z-50`,children:[(0,y.jsx)(`style`,{children:`
          @media print {
            @page { margin: 10mm; size: letter; }
            body { background: white; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          }
        `}),(0,y.jsx)(`div`,{className:`grid grid-cols-3 gap-y-6 gap-x-4`,children:F&&F.qrs.map(e=>(0,y.jsx)(`div`,{className:`break-inside-avoid flex justify-center`,children:(0,y.jsx)(m,{qrCode:e,productoNombre:F.nombre,ordenId:0,clienteNombre:F.tiendaNombre,acabado:`-`,size:80,showPrint:!1})},e))})]})]})}export{b as default};